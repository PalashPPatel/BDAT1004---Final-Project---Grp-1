from common.database import Database
import pandas as pd


class DataDownloader:
    def __init__(self):
        Database.initialize()
        self.collection = "spotify_youtube_collection"
        self.csv_url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vTU9KIKzHswViANp5rOt4_XCmj0FaiFe3hdvSPgR3MpwSmEOMApXshheJCAQ2dchw/pub?gid=1246885931&single=true&output=csv"

    def del_previous_data(self):
        try:
            Database.delete_many(collection=self.collection)
            print("Old data deleted successfully")
        except Exception as e:
            print(f"Exception occured {e}")
            exit(1)

    def store_data_to_mongo(self):
        try:
            df = pd.read_csv(self.csv_url)
            Database.insert_many(
                collection=self.collection, list_of_data=df.to_dict("records")
            )
            print(f"Latest Data inserted successfully")
        except Exception as e:
            print(f"Exception occurred: {e}")


datadlr = DataDownloader()
datadlr.del_previous_data()
datadlr.store_data_to_mongo()
