#!/bin/bash

cd '/home/shivd/studies/georgian/dataprogramming/finalproj';
source venv/bin/activate;
python download.py;

