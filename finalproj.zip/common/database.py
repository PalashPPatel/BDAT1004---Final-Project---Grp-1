import pymongo


class Database(object):
    URI = "mongodb://127.0.0.1:27017"
    DATABASE = None

    @staticmethod
    def initialize():
        client = pymongo.MongoClient(Database.URI)
        Database.DATABASE = client["georgiandb"]

    @staticmethod
    def insert(collection, data):
        # print(f"data: {data}")
        Database.DATABASE[collection].insert_one(data)

    @staticmethod
    def insert_many(collection, list_of_data):
        # print(f"data: {data}")
        Database.DATABASE[collection].insert_many(list_of_data)

    @staticmethod
    def find(
        collection,
        query,
        limit=None,
        no_cursor_timeout=False,
        sortby=None,
        sortby_asc=True,
    ):
        # print("query is {}".format(query))
        if sortby is None:
            if limit is None:
                return Database.DATABASE[collection].find(
                    filter=query, no_cursor_timeout=no_cursor_timeout
                )
            else:
                return (
                    Database.DATABASE[collection]
                    .find(filter=query, no_cursor_timeout=no_cursor_timeout)
                    .limit(limit)
                )
        else:
            if limit is None:
                if sortby_asc:
                    return (
                        Database.DATABASE[collection]
                        .find(filter=query, no_cursor_timeout=no_cursor_timeout)
                        .sort([(sortby, pymongo.ASCENDING)])
                    )
                else:
                    return (
                        Database.DATABASE[collection]
                        .find(filter=query, no_cursor_timeout=no_cursor_timeout)
                        .sort([(sortby, pymongo.DESCENDING)])
                    )
            else:
                if sortby_asc:
                    return (
                        Database.DATABASE[collection]
                        .find(filter=query, no_cursor_timeout=no_cursor_timeout)
                        .limit(limit)
                        .sort([(sortby, pymongo.ASCENDING)])
                    )
                else:
                    return (
                        Database.DATABASE[collection]
                        .find(filter=query, no_cursor_timeout=no_cursor_timeout)
                        .limit(limit)
                        .sort([(sortby, pymongo.DESCENDING)])
                    )

    @staticmethod
    def find_one(collection, query):
        # print("find query is: {} for collection {}".format(query, collection))
        return Database.DATABASE[collection].find_one(query)

    @staticmethod
    def count(collection, query):
        # print("find query is: {} for collection {}".format(query, collection))
        return Database.DATABASE[collection].find_one(query).count()

    @staticmethod
    def update_one(collection, filter, update):
        # print("update is: {}".format(update))
        result = Database.DATABASE[collection].update_one(filter=filter, update=update)
        return result

    @staticmethod
    def update_many(collection, filter, update):
        # print("update is: {}".format(update))
        result = Database.DATABASE[collection].update_many(filter=filter, update=update)
        return result

    @staticmethod
    def delete_many(collection):
        print("Deleting all previous records for collection: {}".format(collection))
        Database.DATABASE[collection].delete_many({})

    @staticmethod
    def find_distinct(collection, query, distinctfield):
        print("query is: {} and distinctfield is: {}".format(query, distinctfield))
        return Database.DATABASE[collection].find(query).distinct(distinctfield)

    @staticmethod
    def find_distinct_in_order(
        collection,
        query,
        distinctfield,
        sortby=None,
        sortby_asc=True,
        limit=0,
        no_cursor_timeout=False,
    ):
        print("query is: {} and distinctfield is: {}".format(query, distinctfield))
        # if sortby_asc == False else pymongo.ASCENDINGs
        return sorted(
            Database.DATABASE[collection]
            .find(filter=query, no_cursor_timeout=no_cursor_timeout)
            .distinct(distinctfield),
            reverse=True,
        )

    @staticmethod
    def find_max(collection, projection, maxoffield):
        # Maxoffield is the field for which you are trying to get the max value
        return Database.DATABASE[collection].find_one(
            {}, projection=projection, sort=[(maxoffield, pymongo.DESCENDING)]
        )

    @staticmethod
    def find_min(collection, minoffield, query={}, projection=None):
        # minoffield is the field for which you are trying to get the max value
        return Database.DATABASE[collection].find_one(
            query, projection=projection, sort=[(minoffield, pymongo.ASCENDING)]
        )
